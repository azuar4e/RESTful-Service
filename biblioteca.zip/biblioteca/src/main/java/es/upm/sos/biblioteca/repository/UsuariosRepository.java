package es.upm.sos.biblioteca.repository;
import es.upm.sos.biblioteca.models.Usuario;
import es.upm.sos.biblioteca.models.Prestamo;


import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;


public interface UsuariosRepository extends JpaRepository<Usuario, String> {

    //Obtener un usuario en base a su matricula
    @Query(value = "SELECT u FROM Usuario u WHERE u.matricula = :matricula")
    Usuario getUsuario(String matricula );

    //Query para hacer update de algun dato de usuario
   // @Query("UPDATE Usuario u SET u.matricula = :matricula, u.nombre = :nombre, u.fechaNacimiento = :fecha, u.correo = :correo")
    //int actualizarUsuario(String matricula,String nombre, @Param("fecha") String fechaNacimiento, @Param("correo") String correo);

    //Query para obtener a todos los usuarios
    @Query("SELECT u FROM Usuario u")
    Page<Usuario> getUsuarios(org.springframework.data.domain.Pageable paginable);

    @Query(value = "SELECT * FROM prestamos WHERE usuario_matricula = :matricula", nativeQuery = true)
    Page<Prestamo> findByPrestamosUsuarioMatricula(@Param("matricula") String matricula, org.springframework.data.domain.Pageable pageable);

    @Query(value = "SELECT * FROM prestamos WHERE usuario_matricula = :matricula AND fecha_prestamo = :fecha_prestamo", nativeQuery = true)
    Page<Prestamo> findByPrestamosUsuarioMatriculaAndFechaPrestamo(@Param("matricula") String matricula, @Param("fecha_prestamo") LocalDate fecha_prestamo, org.springframework.data.domain.Pageable pageable);

    @Query(value = "SELECT * FROM prestamos WHERE usuario_matricula = :matricula AND fecha_devolucion = :fecha_devolucion", nativeQuery = true)
    Page<Prestamo> findByPrestamosUsuarioMatriculaAndFechaDevolucion(@Param("matricula") String matricula, @Param("fecha_devolucion") LocalDate fecha_devolucion, org.springframework.data.domain.Pageable pageable);

    @Query(value = "SELECT * FROM prestamos WHERE usuario_matricula = :matricula AND fecha_prestamo = :fecha_prestamo AND fecha_devolucion = :fecha_devolucion", nativeQuery = true)
    Page<Prestamo> findByPrestamosUsuarioMatriculaAndFechaPrestamoAndFechaDevolucion(@Param("matricula") String matricula, @Param("fecha_prestamo") LocalDate fecha_prestamo, @Param("fecha_devolucion") LocalDate fecha_devolucion, org.springframework.data.domain.Pageable pageable);


    Usuario findByCorreo(String correo);

    boolean existsByMatricula(String matricula);
    
    Usuario findByMatricula(String matricula);

    void deleteByMatricula(String matricula);    
}	