package es.upm.sos.biblioteca.Excepciones;

import lombok.*;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ErrorMessage {
private String message;
}