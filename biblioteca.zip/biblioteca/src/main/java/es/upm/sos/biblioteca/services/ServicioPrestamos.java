package es.upm.sos.biblioteca.services;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.stereotype.Service;

import es.upm.sos.biblioteca.models.Libro;
import es.upm.sos.biblioteca.models.Prestamo;
import es.upm.sos.biblioteca.models.Usuario;
import es.upm.sos.biblioteca.repository.LibrosRepository;
import es.upm.sos.biblioteca.repository.PrestamosRepository;
import es.upm.sos.biblioteca.repository.UsuariosRepository;
import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import lombok.*;
import es.upm.sos.biblioteca.Excepciones.Prestamos.PrestamoNotFoundException;
import es.upm.sos.biblioteca.Excepciones.Prestamos.PrestamoVerificadoException;
import es.upm.sos.biblioteca.Excepciones.Prestamos.PrestamoNotFoundContentException;
import es.upm.sos.biblioteca.Excepciones.Libros.LibroNotFoundException;
import es.upm.sos.biblioteca.Excepciones.Prestamos.FechaDevolucionException;
import es.upm.sos.biblioteca.Excepciones.Prestamos.FechasNoValidasException;
import es.upm.sos.biblioteca.Excepciones.Prestamos.PrestamoConflictException;
import es.upm.sos.biblioteca.Excepciones.Prestamos.LibroNoDisponibleException;
import es.upm.sos.biblioteca.Excepciones.Prestamos.UsuarioDevolucionesPendientesException;
import es.upm.sos.biblioteca.Excepciones.Prestamos.UsuarioSancionadoException;
import es.upm.sos.biblioteca.Excepciones.Prestamos.PrestamoDevueltoException;
import es.upm.sos.biblioteca.Excepciones.Usuarios.UsuarioNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
@AllArgsConstructor
public class ServicioPrestamos{    
    private final PrestamosRepository repository;
    private final LibrosRepository repoLibro;
    private final UsuariosRepository userRepo;
    private static final Logger logger = LoggerFactory.getLogger(ServicioPrestamos.class);

    @Autowired
    private UsuariosRepository userrepo;

    public Page<Prestamo> getPrestamos(int page, int size){
    Pageable paginable = PageRequest.of(page, size);
      return repository.findAll(paginable);
    }

    public Prestamo getPrestamoId(int id) {
      Optional<Prestamo> prestamo = repository.findById(id);

      if (!prestamo.isPresent()) { throw new PrestamoNotFoundException(id, null, null); }

      return prestamo.get();
    }

    public Page<Prestamo> getPrestamosPorFechaDevolucion(String matricula, LocalDate fecha_devolucion, int page, int size) {
      Pageable paginable = PageRequest.of(page, size);
      Page<Prestamo> prestamos = repository.findByUsuarioMatriculaAndFechaDevolucion(matricula, fecha_devolucion, paginable);
      if (prestamos == null) { throw new PrestamoNotFoundContentException(matricula, null, fecha_devolucion); }
      return prestamos;
    }

    public Page<Prestamo> getPrestamosPorFechaDevolucionPorFechaPrestamo(String matricula, LocalDate fecha_prestamo, LocalDate fecha_devolucion, int page, int size) {
      Pageable paginable = PageRequest.of(page, size);
      Page<Prestamo> prestamos = repository.findByUsuarioMatriculaAndFechaPrestamoAndFechaDevolucion(matricula, fecha_prestamo, fecha_devolucion, paginable);
      if (prestamos == null) { throw new PrestamoNotFoundContentException(matricula, fecha_prestamo, fecha_devolucion); }
      return prestamos;
    }

    public Page<Prestamo> getUltimosLibrosDevueltos(String matricula, int page, int size) {
      Usuario usuario = userRepo.findByMatricula(matricula);
      if (usuario == null) { throw new UsuarioNotFoundException(matricula); }
      
      Pageable paginable = PageRequest.of(page, size);
      Page<Prestamo> prestamos = repository.getUltimosLibrosDevueltos(matricula, paginable);
      if (prestamos == null) { throw new PrestamoNotFoundContentException(matricula, null, null); }
      return prestamos;
    }

    public Page<Prestamo> getPrestamosActuales(String matricula, int page, int size) {
      Pageable paginable = PageRequest.of(page, size);
      Page<Prestamo> prestamos = repository.getPrestamosActuales(matricula, paginable);
      if (prestamos == null) { throw new PrestamoNotFoundContentException(matricula, null, null); }
      return prestamos;
    }

    @Transactional
    public void actualizarFechaDevolucion(int id, LocalDate fecha_devolucion) {

      Optional<Prestamo> prestamo = repository.findById(id);
      if (!prestamo.isPresent()) { throw new PrestamoNotFoundException((Integer) id, null, null); }

      LocalDate fechaActual = LocalDate.now();
      LocalDate fechaDevolucionActual = repository.findById(id).get().getFecha_devolucion();

      if (fechaActual.isAfter(fechaDevolucionActual)) {
        throw new FechaDevolucionException(fechaActual, fechaDevolucionActual);
      }

      prestamo.get().setFecha_devolucion(fecha_devolucion);
      repository.save(prestamo.get());
    }

    @Transactional
    public void postPrestamo(Prestamo prestamo) {
      Libro libro = repoLibro.findByIsbn(prestamo.getLibro().getIsbn());
      int cantidad = libro.getDisponibles();
      logger.info("Servicio postPrestamo");
      Optional<Prestamo> prestamoExistente = repository.findById(prestamo.getId());
      logger.info("Cantidad: "+cantidad);
      if (prestamoExistente.isPresent()) { throw new PrestamoConflictException(prestamo.getId()); }
      if(cantidad == 0) { throw new LibroNoDisponibleException(libro.getIsbn()); }
      if (prestamo.getUsuario().getPorDevolver() != 0) { throw new UsuarioDevolucionesPendientesException(prestamo.getUsuario().getMatricula()); }
      if (prestamo.getUsuario().getSancion() != null) { throw new UsuarioSancionadoException(prestamo.getUsuario().getMatricula()); } 
      if(prestamo.getFecha_devolucion().isBefore(prestamo.getFecha_prestamo())) { throw new FechasNoValidasException(prestamo.getFecha_prestamo(), prestamo.getFecha_devolucion()); }
      libro.setDisponibles(cantidad-1);
      logger.info("Cantidad: "+ libro.getDisponibles());
      repoLibro.save(libro);
      repository.save(prestamo);
    }

    @Transactional
    public void devolverLibro(int id) {

      Optional<Prestamo> prestamo = repository.findById(id);
      if (!prestamo.isPresent()) { throw new PrestamoNotFoundException(id, null, null); }
      if (prestamo.get().isDevuelto()) { throw new PrestamoDevueltoException(id); }

      if (prestamo.get().getFecha_devolucion().isBefore(LocalDate.now()) && !prestamo.get().isDevuelto()) {
        if (!prestamo.get().isVerificarDevolucion()) { verificarDevolucion(id); }
        Usuario user = userrepo.getUsuario(prestamo.get().getUsuario().getMatricula());
        user.setPorDevolver(user.getPorDevolver() - 1);

        if (user.getPorDevolver() == 0) {
          LocalDate sancion = LocalDate.now().plusWeeks(1);
          user.setSancion(sancion);
        }
        
        userrepo.save(user);
      }
      Libro libro = prestamo.get().getLibro();
      libro.setDisponibles(libro.getDisponibles()+1);
      prestamo.get().setDevuelto(true);
      repoLibro.save(libro);
      repository.save(prestamo.get());
    }

    @Transactional
    public void verificarDevolucion(int id) {
      Optional<Prestamo> prestamo = repository.findById(id);
      if (!prestamo.isPresent()) { throw new PrestamoNotFoundException(id, null, null); }

      if (prestamo.get().getFecha_devolucion().isBefore(LocalDate.now()) 
        && !prestamo.get().isDevuelto() && !prestamo.get().isVerificarDevolucion()) {

        prestamo.get().setVerificarDevolucion(true);
        Usuario user = userrepo.getUsuario(prestamo.get().getUsuario().getMatricula());
        user.setPorDevolver(user.getPorDevolver() + 1);
        userrepo.save(user);
        repository.save(prestamo.get());
      } else { throw new PrestamoVerificadoException(id); }
    }


    @Transactional
    public void deletePrestamo(int id) {
      Optional<Prestamo> prestamo = repository.findById(id);
      if (!prestamo.isPresent()) { throw new PrestamoNotFoundException(id, null, null); }
      Usuario usuario = prestamo.get().getUsuario();
      if (usuario != null) {
        usuario.getPrestamos().remove(prestamo.get()); 
        userrepo.save(usuario);
      }
      prestamo.get().getLibro().setDisponibles(prestamo.get().getLibro().getDisponibles()+1);
      repoLibro.save(prestamo.get().getLibro());
      repository.deleteById(id);
    }
}